# Financial-Econometrics_2021-22
This repository gathers all projects completed in the "Asset Pricing" course of Prof. Catherine Bruneau, for 2021-22 academic year Fall Semester, in the Monnaie Banque Finance Assurance Master's degree, at Université Paris 1 Panthéon-Sorbonne
